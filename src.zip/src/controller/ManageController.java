package controller;

import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import hostel.Allotte;
import hostel.Bed;
import hostel.HostelDatabase;
import hostel.Room;
import hostel.Transactions;
import hostel.Transactions.Monthly;

public class ManageController {

	private Scanner input = new Scanner(System.in);
	private HostelDatabase hostelDB = HostelDatabase.getInstance();

	public boolean isValid(String regex, String word) {
		Pattern pattern = Pattern.compile(regex);
		Matcher match = pattern.matcher(word);
		if (match.find()) {
			return true;
		}
		return false;
	}

	public void viewRoomList() {
		List<Room> roomList = hostelDB.getRoomList();
		System.out.println("\nROOM ID\t\tBLOCK NAME\tROOM TYPE\tBED COUNT\tAVAILABILITY");
		System.out.print("----------------------------------------------------------------------------\n");
		for (int index = 0; index < roomList.size(); index++) {
			Room eachRoom = roomList.get(index);
			System.out.printf("|%10d|", eachRoom.getRoomId());
			System.out.printf("%15s|", eachRoom.getBlockName());
			System.out.printf("%16s|", eachRoom.getRoomType());
			System.out.printf("%14d|", eachRoom.getNonStayingBedCount());
			System.out.printf("%15s|", eachRoom.getAvailability());
			System.out.println();
		}
	}

	public Room isRoomAvailable(int roomId) {
		List<Room> room = hostelDB.getRoomList();
		for (int index = 0; index < room.size(); index++) {
			Room eachRoom = room.get(index);
			if (eachRoom.getRoomId() == roomId && eachRoom.getNonStayingBedCount() > 0) {
				return eachRoom;
			}
		}
		return null;
	}

	public Room roomIdCheck(int roomId) {
		List<Room> room = hostelDB.getRoomList();
		for (int index = 0; index < room.size(); index++) {
			Room eachRoom = room.get(index);
			if (eachRoom.getRoomId() == roomId) {
				return eachRoom;
			}
		}
		return null;
	}

	public void viewBedList(Room room) {
		List<Bed> bedList = room.viewNonStayingBed();
		System.out.println("\nBED ID\t\tBED SIZE");
		System.out.println("-------------------------");
		for (int index = 0; index < bedList.size(); index++) {
			Bed eachBed = bedList.get(index);
			System.out.printf("|%9d|", eachBed.getBedId());
			System.out.printf("%13s|", eachBed.getBedSize());
			System.out.println();
		}
	}

	public Bed isBedAvailable(Room room, int bedId) {
		List<Bed> bedList = room.viewNonStayingBed();
		for (int index = 0; index < bedList.size(); index++) {
			Bed eachBed = bedList.get(index);
			if (eachBed.getBedId() == bedId)
				return eachBed;
		}
		return null;
	}

	public void viewAllotteList() {
		List<Allotte> allotteList = hostelDB.getAllotteList();
		System.out.println("\nSTAYING ROOM ID \tSTAYING BED ID  \tALLOTTE ID\tALLOTTE NAME\tPHONE NO \t\tADDRESS");
		System.out.print(
				"----------------------------------------------------------------------------------------------------------------\n");
		for (int index = 0; index < allotteList.size(); index++) {
			Allotte eachAllotte = allotteList.get(index);
			System.out.printf("|%17d|", eachAllotte.getStayRoomId());
			System.out.printf("%19d|", eachAllotte.getStayBedId());
			System.out.printf("%19d|", eachAllotte.getAlotteId());
			System.out.printf("%25s|", eachAllotte.getAlotteName());
			System.out.printf("%12d|", eachAllotte.getPhoneNo());
			System.out.printf("%14s|", eachAllotte.getAddress());
			System.out.println();
		}
	}

	public Allotte viewAllotte(int allotteId) {
		List<Allotte> allotteList = hostelDB.getAllotteList();
		System.out.println("\nSTAYING ROOM ID \tSTAYING BED ID  \tALLOTTE ID\tALLOTTE NAME\tPHONE NO \t\tADDRESS");
		System.out.print(
				"----------------------------------------------------------------------------------------------------------------\n");
		for (int index = 0; index < allotteList.size(); index++) {
			Allotte eachAllotte = allotteList.get(index);
			if (eachAllotte.getAlotteId() == allotteId) {
				System.out.printf("|%17d|", eachAllotte.getStayRoomId());
				System.out.printf("%19d|", eachAllotte.getStayBedId());
				System.out.printf("%19d|", eachAllotte.getAlotteId());
				System.out.printf("%25s|", eachAllotte.getAlotteName());
				System.out.printf("%12d|", eachAllotte.getPhoneNo());
				System.out.printf("%14s|", eachAllotte.getAddress());
				System.out.println();
				return eachAllotte;
			}
		}
		return null;
	}

	public boolean isAllotteAvailable(int allotteId) {
		List<Allotte> allotteList = hostelDB.getAllotteList();
		for (int index = 0; index < allotteList.size(); index++) {
			Allotte eachAllotte = allotteList.get(index);
			if (eachAllotte.getAlotteId() == allotteId) {
				return true;
			}
		}
		return false;
	}

	public double viewTransaction(int allotteId) {
		double sum = 0;

		List<Transactions> TransactList = hostelDB.getTransactionList();
		System.out.println("\nROOM ID \tBED ID  \tALLOTTE ID\tENTRY\tEXIT");
		System.out.print("---------------------------------------------------------------------\n");
		for (int index = 0; index < TransactList.size(); index++) {
			Transactions eachTransact = TransactList.get(index);
			if (eachTransact.getAllotteId() == allotteId) {
				System.out.printf("|%10d|", eachTransact.getRoomId());
				System.out.printf("%10d|", eachTransact.getBedId());
				System.out.printf("%10d|", eachTransact.getAllotteId());
				System.out.printf("%25s|", eachTransact.getEntryTime());
				System.out.printf("%25s|", eachTransact.getExitTime());
				System.out.println();

				List<Monthly> month = eachTransact.viewMonthTransact();
				System.out.println("\n*********************\n");
				System.out.println("\nPaid amount \tDue  \tMonth");
				System.out.print("---------------------------------------\n");
				for (int i = 0; i < month.size(); i++) {
					Transactions.Monthly eachMonth = month.get(i);
					System.out.printf("|%15f|", eachMonth.getPaid());
					System.out.printf("%15f|", eachMonth.getDue());
					System.out.printf("%19s|", eachMonth.getCurrentMonth());
					System.out.println();
					if (eachMonth.getDue() >= 0) {
						sum = sum + eachMonth.getDue();
					}
				}
				return sum;
			}
		}
		return 0;
	}

	public Transactions getTransaction(int allotteId) {

		List<Transactions> TransactList = hostelDB.getTransactionList();
		for (int index = 0; index < TransactList.size(); index++) {
			Transactions eachTransact = TransactList.get(index);
			if (eachTransact.getAllotteId() == allotteId) {

				return eachTransact;
			}
		}
		return null;
	}

	public void check(double due, Room room, Bed bed, Allotte allotte, Transactions transact) {
		double paid;
		System.out.print("enter the amount to pay--->");
		paid = input.nextDouble();
		if (paid == due) {
			room.deleteStayingBed(bed);
			room.addNonStayingBed(bed);
			hostelDB.deleteAllotteList(allotte);
			hostelDB.deleteTransactList(transact);
			System.out.println("\nSuccesfully removed...\n THANK YOU ");
		} else {
			System.out.println("\nEnter the full due amount to vacate from the hostel--->");
			check(due, room, bed, allotte, transact);
		}
	}

}
