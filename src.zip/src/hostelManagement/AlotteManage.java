package hostelManagement;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import controller.ManageController;
import controller.SetupController;
import hostel.Allotte;
import hostel.Bed;
import hostel.HostelDatabase;
import hostel.Room;
import hostel.Transactions;

public class AlotteManage {
	private Allotte allotte;
	private ManageController manage;
	private SetupController setup;
	private Transactions transact;
	private Transactions.Monthly month;
	private HostelDatabase hostelDB = HostelDatabase.getInstance();
	private Scanner input = new Scanner(System.in);
	private String roomId, bedId, allotteId;
	private String allotteName, address, entry, currentMonth, exit;
	private String phoneNo, paid, due;

	AlotteManage() {
		manage = new ManageController();
		setup = new SetupController();
	}

	public void Allot() {
		System.out.println("You can allot allottes in the available room now");
		registerAllotte();
	}

	public void deAllot() {
		System.out.println("You can remove allottes from the available room now");
		removeAllotte();

	}

	public void viewAllotte() {
		if (setup.isAllotteSetUped()) {
			System.out.println("Enter Allotte Id");
			allotteId = input.next();
			if (manage.isAllotteAvailable(Integer.valueOf(allotteId)))
				manage.viewAllotteList();
		}
		else {
			System.out.println("Allottes not yet added");	
		}
	}

	private void registerAllotte() {
		System.out.println("----- you can see the availability status of Room below  -----");
		manage.viewRoomList();
		try {
			System.out.print("Enter Room id : ");
			roomId = input.nextLine();

			Room eachRoom = manage.isRoomAvailable(Integer.valueOf(roomId));

			if (eachRoom != null) {
				System.out.print("Room Available\n you can check the available bed List now...");
				manage.viewBedList(eachRoom);
				System.out.print("Choose Bed id : ");
				bedId = input.nextLine();

				Bed eachBed = manage.isBedAvailable(eachRoom, Integer.valueOf(bedId));

				if (eachBed != null) {
					System.out.print("\nEnter Alotte id : ");
					allotteId = input.nextLine();
					if ((manage.isValid("^[1-9][0-9][0-9][0-9][1-9]$", allotteId)) == false) {

						while ((manage.isValid("^[1-9][0-9][0-9][0-9][1-9]$", allotteId)) == false) {
							System.out.println("Invalid Allotte Id !  ----  Enter Allotte ID again (e.g. 10001)");
							allotteId = input.nextLine();

						}
					}

					if (!manage.isAllotteAvailable(Integer.valueOf(allotteId))) {
						System.out.print("\nEnter Alotte Name : ");
						allotteName = input.nextLine();
						if ((manage.isValid("^[a-zA-Z ]+$", allotteName)) == false) {

							while ((manage.isValid("^[a-zA-Z ]+$", allotteName)) == false) {
								System.out.println(
										"Invalid Allotte Name !  ----  Enter Allotte Name again (e.g.  Mugi k)    (No numbers Included)");
								allotteName = input.nextLine();

							}
						}
						System.out.print("\nEnter Alotte PhoneNo. : ");
						phoneNo = input.nextLine();
						if ((manage.isValid("^[6-9][0-9]{9}", phoneNo)) == false) {

							while ((manage.isValid("^[6-9][0-9]{9}", phoneNo)) == false) {
								System.out.println(
										"Invalid Phone No. !  ----  Enter Phone Number again (indian phone number(10 digits))");
								phoneNo = input.nextLine();

							}
						}
						System.out.print("\nEnter Alotte Address :  ");
						address = input.nextLine();

						allotte = new Allotte(Integer.valueOf(roomId), Integer.valueOf(bedId),
								Integer.valueOf(allotteId), allotteName, Long.valueOf(phoneNo), address);
						hostelDB.addAllotteList(allotte);
						eachRoom.addStayingBed(eachBed);
						eachRoom.deleteNonStayingBed(eachBed);

						transact = new Transactions(Integer.valueOf(roomId), Integer.valueOf(bedId),
								Integer.valueOf(allotteId));
						entry = new SimpleDateFormat("EEE / dd-MMM-YYYY / hh:mm:ss aa")
								.format(Calendar.getInstance().getTime());

						transact.setEntryTime(entry);
						System.out.println("\n" + allotteName + " with Id " + allotteId + " is Allotted in the Bed ID"
								+ bedId + " in Room " + roomId + " on  " + entry);

						System.out.println("\nAmount for 1 month is --- 3000");
						System.out.print("\nEnter the amount you want to pay as of now ------ ");
						paid = input.nextLine();

						if ((manage.isValid("^[1-9][0-9]+$", paid)) == false) {

							while ((manage.isValid("^[1-9][0-9]+$", paid)) == false) {
								System.out.println(
										"Invalid paid Amount!  ----  Enter paying amount again (No alphabets included)");
								paid = input.nextLine();
							}
						}

						while (Double.valueOf(paid) < 1500) {
							System.out.println("\nYou must pay atleast 1500 as advance... enter amount to pay");
							paid = input.nextLine();
						}
						if (Double.valueOf(paid) >= 1500 && Double.valueOf(paid) <= 3000) {
							due = ((Double) (3000 - Double.valueOf(paid))).toString();
							if (Double.valueOf(paid) == 3000)
								System.out.println("You paid full amount Rs." + paid);
							else
								System.out.println("You paid Rs." + paid + "  with DUE amount of Rs." + due);
							currentMonth = new SimpleDateFormat("MMM").format(Calendar.getInstance().getTime());
							transact.setMonthTransaction(
									new Transactions.Monthly(Double.valueOf(paid), Double.valueOf(due), currentMonth));
							hostelDB.addTransactionList(transact);
						} else {
							System.out.println("Please give amount within 3000  (Note : don't give tips amount)");
						}
					} else {
						System.out.println("Allotte Id already Exists");
						registerAllotte();
					}

				} else {
					System.out.println(
							"\nSorry ....  You have given WRONG BED ID or Bed you chose is currently NOT Available\nPlease Select other room with available option ");
					registerAllotte();
				}

			} else {
				System.out.println(
						"\nSorry .... Room you chose is currently NOT Available or You have given wrong RoomID\nPlease Select other room with available option ");
				registerAllotte();
			}
		} catch (NumberFormatException e) {
			System.out.println("Enter valid input");
		} catch (InputMismatchException e) {
			System.out.println("Enter valid input");
		}
	}

	private void removeAllotte() {
		double due;
		System.out.println("\nEnter Alotte id : ");
		allotteId = input.next();
		if (manage.isAllotteAvailable(Integer.valueOf(allotteId))) {
			Allotte allotte = manage.viewAllotte(Integer.valueOf(allotteId));
			System.out.println("\n*********************\n");
			Transactions transact = manage.getTransaction(Integer.valueOf(allotteId));

			due = manage.viewTransaction(Integer.valueOf(allotteId));

			roomId = ((Integer) allotte.getStayRoomId()).toString();
			bedId = ((Integer) allotte.getStayBedId()).toString();

			Room room = manage.isRoomAvailable(Integer.valueOf(roomId));
			Bed bed = manage.isBedAvailable(room, Integer.valueOf(bedId));
			if (due == 0) {
				room.deleteStayingBed(bed);
				room.addNonStayingBed(bed);
				hostelDB.deleteAllotteList(allotte);
				hostelDB.deleteTransactList(transact);
				System.out.println("succesfully removed...\n THANK YOU ");
			} else {
				System.out.println("\n***************************\nALLOTTE ID " + allotteId + " have Due of Rs. " + due
						+ "\n please clear it...");
				manage.check(due, room, bed, allotte, transact);
			}
		} else
			System.out.println("You have entered wrong allotte Id");
	}

}
