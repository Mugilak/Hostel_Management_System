package hostelManagement;

import java.util.InputMismatchException;
import java.util.Scanner;
import controller.ManageController;
import hostel.Bed;
import hostel.HostelDatabase;
import hostel.Room;

public class RoomManage {

	private String roomId, bedId, blockName, roomType, bedSize;
	private Scanner input = new Scanner(System.in);
	private Bed bed;
	private Room room;
	private ManageController manage;
	private AlotteManage alotteManage;
	private HostelDatabase hostelDB = HostelDatabase.getInstance();
	private int choice = 1, choose;
	boolean found = false;

	RoomManage() {
		manage = new ManageController();
		alotteManage = new AlotteManage();
	}

	public void create() {
		System.out.println("ADD ROOM");
		addRoomList();
		System.out.println("ADD BED");
		addBed();
	}

	public void getUserChoice() {
		try {
			do {
				System.out.println("""
						\n1. Add ROOMS
						2. Add BEDS
						3. Add both ROOMS and BEDS
						4. Add Allotte
						5. See Allotte details
						6. Remove Allotte
						press corresponding number to do operation----
						""");
				try {
					choose = input.nextInt();
					switch (choose) {
					case 1:
						addRoomList();
						break;
					case 2:
						addBed();
						break;
					case 3:
						addRoomList();
						addBed();
						break;
					case 4:
						alotteManage.Allot();
						break;
					case 5:
						alotteManage.viewAllotte();
						break;
					case 6:
						alotteManage.deAllot();
						break;
					default:
						System.out.println("Enter valid number to  do operations");
					}
				} catch (NumberFormatException e) {
					System.out.println("please..Press any number to continue operation");
				}

				System.out.println("press  1--> to continue the operations.   other numbers-- to exit");
				choice = input.nextInt();
			} while (choice == 1);
			System.out.println("Thank You");
		} catch (NumberFormatException e) {
			System.out.println("Press any number");
		}
	}

	private void addRoomList() {
		try {
			System.out.println("Enter no.of Rooms you want to add");
			choice = input.nextInt();
			input.nextLine();
			int i = 1;
			loop: while (i <= choice) {
				System.out.println("Enter Room ID");
				roomId = input.nextLine();
				if (manage.isValid("^[1-9][0-9][0-9]$", roomId)) {
					if ((manage.roomIdCheck(Integer.valueOf(roomId))) == null) {
						System.out.println("Enter Room Block");
						blockName = input.nextLine();

						if ((manage.isValid("^[a-zA-Z]+$", blockName)) == false) {

							while ((manage.isValid("^[a-zA-Z]+$", blockName)) == false) {
								System.out.println(
										"Invalid Block Name !  ----  Enter Block Name again (No numbers Included)");
								blockName = input.nextLine();

							}
						}
						System.out.println("Enter Room Type (Single / Shared)");
						roomType = input.nextLine();
						if (!(roomType.equalsIgnoreCase("single") || roomType.equalsIgnoreCase("shared"))) {
							while (!(roomType.equalsIgnoreCase("single") || roomType.equalsIgnoreCase("shared"))) {
								System.out
										.println("Invalid room Type !  ----  Enter Room Type again (Single / Shared)");
								roomType = input.nextLine();
							}
						}
						room = new Room(Integer.valueOf(roomId), blockName, roomType, Room.Status.YES);
						hostelDB.addRoomList(room);
						System.out.println(i + "st Room added\n");

						i++;
					} else {
						System.out.println("RoomId already exists ! give correct new room Id again");
						continue loop;
					}
				} else {
					System.out.println("Invalid roomId ! give Valid room Id again (e.g. 123) ");
					continue loop;
				}
			}
			if (i == choice + 1)
				System.out.println(choice + " ROOMS added\n");

		} catch (NumberFormatException e) {
			System.out.println("Press valid input");
		}
	}

	private void addBed() {
		try {
			System.out.println("Enter Room ID where you want to add Bed");
			roomId = input.next();
			room = manage.roomIdCheck(Integer.valueOf(roomId));
			if (room != null) {
				System.out.println("Enter no.of Beds you want to add");
				choice = input.nextInt();
				int i = 1;
				while (i <= choice) {
					input.nextLine();
					System.out.println("Enter Bed ID");
					bedId = input.nextLine();
					if ((manage.isValid("^[1-9][0-9][0-9][1-9]$", bedId)) == false) {

						while ((manage.isValid("^[1-9][0-9][0-9][1-9]$", bedId)) == false) {
							System.out.println("Invalid Bed ID !  ----  Enter Bed ID again (e.g.  1001)");
							bedId = input.nextLine();

						}
					}
					if (manage.isBedAvailable(room, Integer.valueOf(bedId)) == null) {
						System.out.println("Enter Bed Size");
						bedSize = input.next();
						bed = new Bed(Integer.valueOf(bedId), bedSize);
						room.setBed(bed);
						room.setNonStayingBed();
						System.out.println(i + "st Bed added\n");

					} else {
						System.out.println("Bed Id already exists in the room " + roomId + " ..... give again");
						continue;
					}

					i++;
				}
				if (i == choice + 1)
					System.out.println("Totally " + choice + " BEDS added\n");
			}
		} catch (NumberFormatException e) {
			System.out.println("Enter valid input");
		} catch (InputMismatchException e) {
			System.out.println("Enter valid input");
		}
	}

	private void deleteRoom() {
		System.out.println("Enter room ID which you want to delete");
	}

}
